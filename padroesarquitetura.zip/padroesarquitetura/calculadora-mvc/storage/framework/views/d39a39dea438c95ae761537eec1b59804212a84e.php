<div>
    7
    <button wire:click="sum">+</button>
    <?php echo e($result); ?>

</div>
<?php /**PATH /var/www/resources/views/livewire/show-calculator.blade.php ENDPATH**/ ?>