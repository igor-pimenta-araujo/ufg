<div>
    
    <h1>Posts</h1>
</div>
<?php /**PATH /var/www/resources/views/livewire/show-posts.blade.php ENDPATH**/ ?>