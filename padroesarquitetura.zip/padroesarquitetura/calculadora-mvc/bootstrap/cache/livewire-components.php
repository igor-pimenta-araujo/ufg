<?php return array (
  'calculator' => 'App\\Http\\Livewire\\Calculator',
  'show-calculator' => 'App\\Http\\Livewire\\ShowCalculator',
  'show-posts' => 'App\\Http\\Livewire\\ShowPosts',
);