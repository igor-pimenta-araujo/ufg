<div>
    {{-- In work, do what you enjoy. --}}
    <h1>Posts</h1>
</div>
