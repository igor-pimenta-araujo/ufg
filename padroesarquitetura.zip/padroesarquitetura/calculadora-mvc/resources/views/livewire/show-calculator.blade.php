<div>
    {{-- In work, do what you enjoy. --}}7
    <button wire:click="sum">+</button>
    {{ $result }}
</div>
