<?php return array (
  'postform' => 'App\\Http\\Livewire\\Postform',
  'userform' => 'App\\Http\\Livewire\\Userform',
);