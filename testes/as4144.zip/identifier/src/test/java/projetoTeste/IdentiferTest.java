package projetoTeste;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import src.Identifier;

public class IdentiferTest {

	private Identifier id;
	@Before
	public void setUp() throws Exception {
		id = new Identifier();
	}

	//cenário de teste 1:

	//cenário de teste 2:

	//cenário de teste 3:

	//cenário de teste 4:

	//cenário de teste 5:

	//cenário de teste 6:

}
