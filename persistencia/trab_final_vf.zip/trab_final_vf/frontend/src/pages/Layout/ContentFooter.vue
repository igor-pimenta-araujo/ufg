<template>
  <footer class="footer">
    <div class="container">
      <div class="copyright text-center">
        &copy; {{ new Date().getFullYear() }}
        <a target="_blank">Igor Araujo & João Pedro</a>
      </div>
    </div>
  </footer>
</template>
<script>
export default {};
</script>
