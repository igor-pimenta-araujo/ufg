<template>
  <div class="content">
    <div class="md-layout">
      <div class="md-layout-item md-medium-size-100 md-size-100">
        <agenda-form data-background-color="green"> </agenda-form>
      </div>
    </div>
  </div>
</template>

<script>
import { AgendaForm } from "@/pages";

export default {
  components: {
    AgendaForm,
  },
};
</script>
