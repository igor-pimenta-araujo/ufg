<template>
  <div class="content">
    <div class="md-layout">
      <div class="md-layout-item md-medium-size-100 md-size-100">
        <alergia-form data-background-color="green"> </alergia-form>
      </div>
    </div>
  </div>
</template>

<script>
import { AlergiaForm } from "@/pages";

export default {
  components: {
    AlergiaForm,
  },
};
</script>
