package com.persistencia.jpeigor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpeigorApplicationTests {

	@Test
	void contextLoads() {
	}

}
