package com.persistencia.jpeigor.repositories;

import com.persistencia.jpeigor.models.Alergia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlergiaRepository extends JpaRepository<Alergia, Integer> {
}
