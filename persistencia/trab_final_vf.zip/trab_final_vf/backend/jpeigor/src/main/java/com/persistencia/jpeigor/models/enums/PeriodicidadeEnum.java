package com.persistencia.jpeigor.models.enums;

public enum PeriodicidadeEnum {
    dias,
    semanas,
    meses,
    anos
}
