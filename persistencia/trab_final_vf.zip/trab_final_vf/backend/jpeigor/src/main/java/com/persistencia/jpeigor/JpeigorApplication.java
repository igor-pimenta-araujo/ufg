package com.persistencia.jpeigor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpeigorApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpeigorApplication.class, args);
	}

}
