package com.persistencia.jpeigor.models.enums;

public enum SituacaoEnum {
    Agendado,
    Realizado,
    Cancelado
}
