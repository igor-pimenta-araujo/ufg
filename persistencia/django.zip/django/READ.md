## Como subir o projeto
1. Com o terminal no repositório django, fazer o comando:
	- `source venv/bin/activate`
2. Após isso, realizar o comando pra mudar pra pasta mysite:
	- `cd mysite`
3. Após isso, realizar o comando pra subir o servidor:
	- `python manage.py runserver`
4. Após isso, acessar via http://localhost:8000/polls/ o projeto via navegador
	- se atentar ao terminal porque a porta pode ser diferente.